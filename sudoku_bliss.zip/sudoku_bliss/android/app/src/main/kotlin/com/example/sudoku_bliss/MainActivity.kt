package com.example.sudoku_bliss

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
