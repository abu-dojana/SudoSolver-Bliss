import 'dart:async';
import 'package:flutter/material.dart';

class BySetState extends StatefulWidget {
  @override
  _BySetStateState createState() => _BySetStateState();
}

class _BySetStateState extends State<BySetState> {
  int _counter = 50;
  late Timer _timer;

  void _startTimer() {
    
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}